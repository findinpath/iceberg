/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.iceberg;

import java.util.List;
import org.apache.iceberg.types.Types;

interface ContentStats extends StructLike {

  /** A list of all the {@link FieldStats} */
  List<FieldStats<?>> fieldStats();

  /**
   * Returns a {@link FieldStats} instance holding field stats for the given field ID.
   *
   * @param fieldId The field ID to retrieve {@link FieldStats} for
   * @return A {@link FieldStats} instance holding field stats for the given field ID.
   * @param <T> The type of the underlying {@link FieldStats} instance.
   */
  <T> FieldStats<T> statsFor(int fieldId);

  /** The stats struct holding nested structs with their respective field stats */
  Types.StructType statsStruct();
}
