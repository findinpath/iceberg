/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.iceberg.actions;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import org.apache.iceberg.DeleteFile;
import org.apache.iceberg.FileScanTask;
import org.apache.iceberg.ManifestFile;
import org.apache.iceberg.ManifestFiles;
import org.apache.iceberg.ManifestReader;
import org.apache.iceberg.PartitionSpec;
import org.apache.iceberg.RewriteFiles;
import org.apache.iceberg.Snapshot;
import org.apache.iceberg.SnapshotRef;
import org.apache.iceberg.Table;
import org.apache.iceberg.TableScan;
import org.apache.iceberg.exceptions.RuntimeIOException;
import org.apache.iceberg.exceptions.ValidationException;
import org.apache.iceberg.io.CloseableIterable;
import org.apache.iceberg.io.FileIO;
import org.apache.iceberg.relocated.com.google.common.base.Preconditions;
import org.apache.iceberg.relocated.com.google.common.collect.ImmutableList;
import org.apache.iceberg.relocated.com.google.common.collect.Lists;
import org.apache.iceberg.relocated.com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RemoveDanglingDeleteFilesAction
    extends BaseSnapshotUpdateAction<RemoveDanglingDeleteFiles, RemoveDanglingDeleteFiles.Result>
    implements RemoveDanglingDeleteFiles {

  private static final Logger LOG = LoggerFactory.getLogger(RemoveDanglingDeleteFilesAction.class);
  private static final List<String> DELETE_COLUMNS =
      ImmutableList.of(
          "content",
          "file_path",
          "file_format",
          "partition",
          "record_count",
          "file_size_in_bytes",
          "key_metadata",
          "split_offsets",
          "equality_ids",
          "sort_order_id",
          "first_row_id",
          "referenced_data_file",
          "content_offset",
          "content_size_in_bytes");
  private static final Result EMPTY_RESULT =
      ImmutableRemoveDanglingDeleteFiles.Result.builder()
          .removedDeleteFiles(ImmutableList.of())
          .build();

  private final Table table;
  private final BiFunction<Long, List<ManifestFile>, Collection<DeleteFile>> findDanglingDeletes;
  private String branch = SnapshotRef.MAIN_BRANCH;

  public RemoveDanglingDeleteFilesAction(Table table) {
    this.table = table;
    this.findDanglingDeletes = this::findDanglingDeletes;
  }

  public RemoveDanglingDeleteFilesAction(
      Table table,
      BiFunction<Long, List<ManifestFile>, Collection<DeleteFile>> findDanglingDeletes) {
    this.table = table;
    this.findDanglingDeletes = findDanglingDeletes;
  }

  @Override
  protected RemoveDanglingDeleteFilesAction self() {
    return this;
  }

  @Override
  protected Table table() {
    return table;
  }

  public RemoveDanglingDeleteFilesAction toBranch(String targetBranch) {
    Preconditions.checkArgument(targetBranch != null, "Invalid branch name: null");
    this.branch = targetBranch;
    return this;
  }

  @Override
  public Result execute() {
    Snapshot snapshot = table.snapshot(branch);
    if (snapshot == null) {
      Preconditions.checkArgument(
          branch.equals(SnapshotRef.MAIN_BRANCH),
          "Cannot remove dangling delete files from branch %s: branch does not exist",
          branch);
      return EMPTY_RESULT;
    }

    List<ManifestFile> deleteManifests = snapshot.deleteManifests(table.io());
    if (deleteManifests.isEmpty()) {
      return EMPTY_RESULT;
    }

    Collection<DeleteFile> danglingDeletes =
        findDanglingDeletes.apply(snapshot.snapshotId(), deleteManifests);
    if (danglingDeletes.isEmpty()) {
      return EMPTY_RESULT;
    }

    long snapshotId = snapshot.snapshotId();
    RewriteFiles rewriteFiles =
        table
            .newRewrite()
            .validateFromSnapshot(snapshotId)
            // validate on every commit attempt, including retries after concurrent updates
            .validateWith(
                snapshots -> {
                  Iterator<Snapshot> iterator = snapshots.iterator();
                  Snapshot currentSnapshot = iterator.hasNext() ? iterator.next() : null;
                  ValidationException.check(
                      currentSnapshot != null && currentSnapshot.snapshotId() == snapshotId,
                      "Cannot remove dangling deletes: current snapshot changed from %s to %s",
                      snapshotId,
                      currentSnapshot != null ? currentSnapshot.snapshotId() : null);
                  return true;
                });
    for (DeleteFile deleteFile : danglingDeletes) {
      LOG.debug("Removing dangling delete file {}", deleteFile.location());
      rewriteFiles.deleteFile(deleteFile);
    }

    commit(rewriteFiles.toBranch(branch));

    return ImmutableRemoveDanglingDeleteFiles.Result.builder()
        .removedDeleteFiles(danglingDeletes)
        .build();
  }

  /**
   * Dangling delete files can be identified with following steps
   *
   * <ol>
   *   <li>Make a full scan and collect delete files from all file tasks.
   *   <li>Collect all delete file entries skipping files from the previous step.
   * </ol>
   */
  private List<DeleteFile> findDanglingDeletes(
      long snapshotId, List<ManifestFile> deleteManifests) {
    Set<DeleteFileKey> referencedKeys = Sets.newHashSet();
    TableScan scan = table.newScan().useSnapshot(snapshotId);
    try (CloseableIterable<FileScanTask> tasks = scan.planFiles()) {
      for (FileScanTask task : tasks) {
        for (DeleteFile deleteFile : task.deletes()) {
          referencedKeys.add(new DeleteFileKey(deleteFile));
        }
      }
    } catch (IOException e) {
      throw new RuntimeIOException(e, "Failed to scan: %s", scan);
    }

    List<DeleteFile> danglingDeletes = Lists.newArrayList();
    for (ManifestFile manifest : deleteManifests) {
      try (ManifestReader<DeleteFile> reader =
          readDeleteManifest(manifest, table.io(), table.specs())) {
        for (DeleteFile deleteFile : reader) {
          if (!referencedKeys.contains(new DeleteFileKey(deleteFile))) {
            danglingDeletes.add(deleteFile);
          }
        }
      } catch (IOException e) {
        throw new RuntimeIOException(e, "Failed to read manifest: %s", manifest);
      }
    }

    return danglingDeletes;
  }

  public static ManifestReader<DeleteFile> readDeleteManifest(
      ManifestFile manifest, FileIO io, Map<Integer, PartitionSpec> specsById) {
    return ManifestFiles.readDeleteManifest(manifest, io, specsById).select(DELETE_COLUMNS);
  }

  public static final class DeleteFileKey implements Serializable {
    private final String location;
    private final Long contentOffset;
    private final Long contentSizeInBytes;

    public DeleteFileKey(String location, Long contentOffset, Long contentSizeInBytes) {
      this.location = location;
      this.contentOffset = contentOffset;
      this.contentSizeInBytes = contentSizeInBytes;
    }

    public DeleteFileKey(DeleteFile file) {
      this(file.location(), file.contentOffset(), file.contentSizeInBytes());
    }

    public String location() {
      return location;
    }

    public Long contentOffset() {
      return contentOffset;
    }

    public Long contentSizeInBytes() {
      return contentSizeInBytes;
    }

    @Override
    public boolean equals(Object other) {
      if (this == other) {
        return true;
      }

      return other instanceof DeleteFileKey that
          && Objects.equals(location, that.location)
          && Objects.equals(contentOffset, that.contentOffset)
          && Objects.equals(contentSizeInBytes, that.contentSizeInBytes);
    }

    @Override
    public int hashCode() {
      int result = Objects.hashCode(location);
      result = 31 * result + Objects.hashCode(contentOffset);
      result = 31 * result + Objects.hashCode(contentSizeInBytes);
      return result;
    }

    @Override
    public String toString() {
      return "DeleteFileKey{"
          + "location="
          + location
          + ", contentOffset="
          + contentOffset
          + ", contentSizeInBytes="
          + contentSizeInBytes
          + '}';
    }
  }
}
